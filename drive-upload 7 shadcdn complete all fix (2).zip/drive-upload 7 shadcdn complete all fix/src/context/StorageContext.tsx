'use client';

import { createContext, useContext, useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { supabase } from '@/lib/supabase';

const STORAGE_LIMIT = 107374182400; // 100GB in bytes

type StorageContextType = {
  storage: {
    total: number;
    used: number;
    available: number;
  };
  updateStorage: (change: number) => void;
  refreshStorage: () => Promise<void>;
};

const StorageContext = createContext<StorageContextType>({
  storage: {
    total: STORAGE_LIMIT,
    used: 0,
    available: STORAGE_LIMIT
  },
  updateStorage: () => {},
  refreshStorage: async () => {},
});

export function StorageProvider({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();
  const [storageUsed, setStorageUsed] = useState(0);

  const loadStorageData = async () => {
    if (!session?.user?.id) return;

    try {
      const { data: files, error } = await supabase
        .from('file_logs')
        .select('size')
        .eq('user_id', session.user.id);

      if (error) throw error;

      const total = files?.reduce((acc, file) => acc + (file.size || 0), 0) || 0;
      setStorageUsed(total);
    } catch (error) {
      console.error('Error loading storage data:', error);
    }
  };

  useEffect(() => {
    loadStorageData();
  }, [session?.user?.id]);

  const updateStorage = (change: number) => {
    setStorageUsed(prev => Math.max(0, Math.min(prev + change, STORAGE_LIMIT)));
  };

  return (
    <StorageContext.Provider value={{ 
      storage: {
        total: STORAGE_LIMIT,
        used: storageUsed,
        available: STORAGE_LIMIT - storageUsed
      },
      updateStorage,
      refreshStorage: loadStorageData
    }}>
      {children}
    </StorageContext.Provider>
  );
}

export function useStorage() {
  return useContext(StorageContext);
} 
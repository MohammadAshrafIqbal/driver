'use client';

import React, { createContext, useContext, useState } from 'react';

interface Upload {
  id: string;
  name: string;
  progress: number;
  status: 'uploading' | 'completed' | 'error';
  size: number;
}

interface UploadsContextType {
  uploads: Upload[];
  addUpload: (upload: Upload) => void;
  updateUpload: (id: string, data: Partial<Upload>) => void;
  removeUpload: (id: string) => void;
}

const UploadsContext = createContext<UploadsContextType | undefined>(undefined);

export function UploadsProvider({ children }: { children: React.ReactNode }) {
  const [uploads, setUploads] = useState<Upload[]>([]);

  const addUpload = (upload: Upload) => {
    setUploads(prev => [...prev, upload]);
  };

  const updateUpload = (id: string, data: Partial<Upload>) => {
    setUploads(prev => prev.map(upload => 
      upload.id === id ? { ...upload, ...data } : upload
    ));
  };

  const removeUpload = (id: string) => {
    setUploads(prev => prev.filter(upload => upload.id !== id));
  };

  return (
    <UploadsContext.Provider value={{ uploads, addUpload, updateUpload, removeUpload }}>
      {children}
    </UploadsContext.Provider>
  );
}

export function useUploads() {
  const context = useContext(UploadsContext);
  if (!context) {
    throw new Error('useUploads must be used within a UploadsProvider');
  }
  return context;
} 
export interface UploadResponse {
  fileId: string;
  fileName: string;
  size: number;
  webViewLink: string;
  downloadUrl?: string;
}

export interface SharerResponse {
  success: boolean;
  code: string;
  url: string;
  fileInfo?: {
    name: string;
    size: number;
    mimeType: string;
  };
}

export interface DownloadResponse {
  url: string;
  fileName: string;
  expiry: number;
  hmac: string;
}

export interface FileMetadata {
  id: string;
  fileId: string;
  name: string;
  size: number;
  mimeType: string;
  createdAt: string;
  webViewLink?: string;
  downloadUrl?: string;
  driveUrl?: string;
  thumbnailUrl?: string;
} 
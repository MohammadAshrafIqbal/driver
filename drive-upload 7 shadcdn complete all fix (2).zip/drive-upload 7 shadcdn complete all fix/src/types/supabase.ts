export interface FileLog {
  id: string;
  user_id: string;
  file_name: string;
  file_id: string;
  size: number;
  web_view_link: string;
  action_type: 'upload' | 'clone' | 'share';
  created_at: string;
  sharer_link?: string;
}

export interface SharerLink {
  id: string;
  code: string;
  drive_file_id: string;
  user_id: string;
  created_at: string;
  views: number;
  is_public: boolean;
}

export interface UploadResponse {
  fileId: string;
  fileName: string;
  size: number;
  webViewLink: string;
}

export interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType: string;
  size: string;
  webViewLink: string;
  isPublic?: boolean;
} 
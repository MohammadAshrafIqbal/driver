import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { google } from 'googleapis';
import { supabase } from '@/lib/supabase';
import { authOptions } from '@/lib/auth';

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Please sign in to delete files' }, { status: 401 });
    }

    // First, verify the file exists and belongs to the user
    const { data: fileCheck } = await supabase
      .from('file_logs')
      .select('file_id, file_name')
      .eq('id', params.id)
      .eq('user_id', session.user.email)
      .single();

    if (!fileCheck) {
      return NextResponse.json({ error: 'File not found or unauthorized' }, { status: 404 });
    }

    // Then delete the file
    const { error: deleteError } = await supabase
      .from('file_logs')
      .delete()
      .eq('id', params.id)
      .eq('user_id', session.user.email);

    if (deleteError) {
      console.error('Database deletion error:', deleteError);
      return NextResponse.json({ 
        error: 'Failed to delete from database' 
      }, { status: 500 });
    }

    try {
      // Initialize OAuth2 client for Google Drive
      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET
      );

      oauth2Client.setCredentials({
        refresh_token: process.env.GOOGLE_REFRESH_TOKEN
      });

      // Try to delete from Google Drive
      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      await drive.files.delete({
        fileId: fileCheck.file_id
      });
    } catch (driveError) {
      console.error('Drive deletion error:', driveError);
      // Continue even if Drive deletion fails
    }

    return NextResponse.json({ 
      success: true,
      message: `Successfully deleted ${fileCheck.file_name}`
    });

  } catch (error) {
    console.error('Delete operation failed:', error);
    return NextResponse.json({ 
      error: 'An unexpected error occurred while deleting the file' 
    }, { status: 500 });
  }
} 
import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

interface FileLog {
  file_id: string;
  file_name: string;
  size: number;
  web_view_link: string;
}

interface SharerData {
  code: string;
  views: number;
  file_logs: FileLog;
}

export async function GET(
  request: NextRequest,
  { params }: { params: { code: string } }
) {
  try {
    const { code } = params;

    // Join sharer_links with file_logs using file_id
    const { data, error } = await supabase
      .from('sharer_links')
      .select(`
        code,
        views,
        file_logs!inner (
          file_id,
          file_name,
          size,
          web_view_link
        )
      `)
      .eq('code', code)
      .single<SharerData>();

    if (error) {
      console.error('Database error:', error);
      throw new Error('Failed to fetch sharer link');
    }

    if (!data || !data.file_logs) {
      throw new Error('Sharer link not found');
    }

    // Increment view count
    await supabase
      .from('sharer_links')
      .update({ views: (data.views || 0) + 1 })
      .eq('code', code);

    return NextResponse.json({
      fileId: data.file_logs.file_id,
      fileName: data.file_logs.file_name,
      size: data.file_logs.size,
      webViewLink: data.file_logs.web_view_link
    });

  } catch (error) {
    console.error('Sharer error:', error);
    return NextResponse.json({ error: 'Failed to get sharer link' }, { status: 500 });
  }
} 
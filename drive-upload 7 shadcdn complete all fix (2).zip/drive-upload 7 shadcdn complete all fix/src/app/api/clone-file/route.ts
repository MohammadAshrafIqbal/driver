import { NextRequest, NextResponse } from 'next/server';
import { google } from 'googleapis';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';

// Google OAuth2 configuration
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID!,
  process.env.GOOGLE_CLIENT_SECRET!,
  'http://localhost:3000'
);

oauth2Client.setCredentials({
  refresh_token: process.env.GOOGLE_REFRESH_TOKEN
});

const drive = google.drive({ version: 'v3', auth: oauth2Client });

function extractFileId(url: string): string | null {
  try {
    const patterns = [
      /\/file\/d\/([^/]+)/,  // https://drive.google.com/file/d/FILE_ID/view
      /id=([^&]+)/,          // https://drive.google.com/open?id=FILE_ID
      /\/d\/([^/]+)/,        // Other possible formats
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }

    return null;
  } catch (error) {
    console.error('Error extracting file ID:', error);
    return null;
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const url = body.url;

    if (!url) {
      return NextResponse.json({ error: 'URL is required' }, { status: 400 });
    }

    const fileId = extractFileId(url);
    console.log('Extracted File ID:', fileId); // Debug log

    if (!fileId) {
      return NextResponse.json(
        { error: 'Invalid Google Drive URL' },
        { status: 400 }
      );
    }

    // First, verify we can access the file
    console.log('Fetching source file metadata...'); // Debug log
    const sourceFile = await drive.files.get({
      fileId,
      fields: 'name,size,mimeType',
      supportsAllDrives: true,
    }).catch(error => {
      console.error('Error getting source file:', error);
      throw new Error('Cannot access the source file. Make sure it\'s publicly accessible.');
    });

    console.log('Source file found:', sourceFile.data); // Debug log

    // Clone the file
    console.log('Cloning file...'); // Debug log
    const clonedFile = await drive.files.copy({
      fileId,
      requestBody: {
        name: sourceFile.data.name,
      },
      fields: 'id,name,webViewLink',
      supportsAllDrives: true,
    }).catch(error => {
      console.error('Error copying file:', error);
      throw new Error('Failed to clone the file. The file might be too large or not supported.');
    });

    console.log('File cloned:', clonedFile.data); // Debug log

    // Make the cloned file publicly accessible
    console.log('Setting permissions...'); // Debug log
    await drive.permissions.create({
      fileId: clonedFile.data.id!,
      requestBody: {
        role: 'reader',
        type: 'anyone',
      },
      supportsAllDrives: true,
    }).catch(error => {
      console.error('Error setting permissions:', error);
      // Don't throw here, as the file is already cloned
    });

    return NextResponse.json({
      success: true,
      fileId: clonedFile.data.id,
      fileName: clonedFile.data.name,
      size: Number(sourceFile.data.size || 0),
      webViewLink: clonedFile.data.webViewLink,
    });

  } catch (error) {
    console.error('Clone operation failed:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to clone file';
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
} 
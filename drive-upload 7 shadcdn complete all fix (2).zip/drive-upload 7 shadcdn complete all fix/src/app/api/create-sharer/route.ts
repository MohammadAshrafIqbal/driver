import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { supabase } from '@/lib/supabase';
import { nanoid } from 'nanoid';
import { extractFileId } from '@/lib/utils/drive';

export async function POST(request: NextRequest) {
  try {
    const token = await getToken({ req: request });
    if (!token?.sub) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { driveUrl, fileName, fileSize } = await request.json();
    if (!driveUrl) {
      return NextResponse.json({ error: 'Drive URL is required' }, { status: 400 });
    }

    const fileId = extractFileId(driveUrl);
    if (!fileId) {
      return NextResponse.json({ error: 'Invalid Drive URL' }, { status: 400 });
    }

    // Generate unique code for the share link
    const code = nanoid(10);
    const sharerUrl = `${process.env.NEXTAUTH_URL}/s/${code}`;

    // Create sharer link using the function
    const { data, error } = await supabase
      .rpc('create_sharer_link', {
        p_user_id: token.sub,
        p_drive_file_id: fileId,
        p_file_name: fileName,
        p_file_size: fileSize,
        p_web_view_link: driveUrl,
        p_code: code,
        p_sharer_link: sharerUrl
      });

    if (error) {
      console.error('Transaction error:', error);
      return NextResponse.json({
        error: 'Failed to create sharer link',
        details: error.message
      }, { status: 500 });
    }

    return NextResponse.json(data);

  } catch (error: any) {
    console.error('Create sharer error:', error);
    return NextResponse.json({ 
      error: 'Failed to create sharer link',
      details: error.message 
    }, { status: 500 });
  }
} 
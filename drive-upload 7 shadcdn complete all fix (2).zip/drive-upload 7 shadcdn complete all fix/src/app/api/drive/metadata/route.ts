import { NextRequest, NextResponse } from 'next/server';
import { google } from 'googleapis';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const fileId = searchParams.get('fileId');

    if (!fileId) {
      return NextResponse.json({ error: 'File ID is required' }, { status: 400 });
    }

    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    const file = await drive.files.get({
      fileId: fileId,
      fields: 'id, name, size, mimeType, webViewLink'
    });

    if (!file.data) {
      throw new Error('File not found');
    }

    return NextResponse.json({
      id: file.data.id,
      name: file.data.name,
      size: Number(file.data.size || 0),
      mimeType: file.data.mimeType,
      webViewLink: file.data.webViewLink
    });

  } catch (error: any) {
    console.error('Metadata error:', error.message);
    return NextResponse.json({ 
      error: 'Failed to get file metadata',
      details: error.message 
    }, { status: 500 });
  }
} 
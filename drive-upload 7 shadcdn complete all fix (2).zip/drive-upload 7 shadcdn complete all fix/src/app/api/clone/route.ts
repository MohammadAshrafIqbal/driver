import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';
import { supabase } from '@/lib/supabase';
import { google } from 'googleapis';
import { extractFileId } from '@/lib/utils/drive';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { driveUrl } = await request.json();
    
    // Initialize Google Drive client
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    // Extract file ID from URL
    const fileId = extractFileId(driveUrl);
    if (!fileId) {
      return NextResponse.json({ error: 'Invalid Drive URL' }, { status: 400 });
    }

    // Get source file metadata
    const sourceFile = await drive.files.get({
      fileId: fileId,
      fields: 'id,name,size,mimeType'
    });

    // Clone the file with additional fields in the response
    const clonedFile = await drive.files.copy({
      fileId: fileId,
      requestBody: {
        name: sourceFile.data.name
      },
      fields: 'id, name, size, webViewLink'
    });

    // Make the file publicly accessible
    await drive.permissions.create({
      fileId: clonedFile.data.id!,
      requestBody: {
        role: 'reader',
        type: 'anyone'
      }
    });

    // Generate webViewLink if it's not provided
    const webViewLink = clonedFile.data.webViewLink || `https://drive.google.com/file/d/${clonedFile.data.id}/view`;

    // Log the clone operation
    const { error: logError } = await supabase
      .from('file_logs')
      .insert({
        user_id: session.user.id,
        file_name: sourceFile.data.name,
        file_id: clonedFile.data.id!,
        size: Number(sourceFile.data.size || 0),
        web_view_link: webViewLink,
        action_type: 'clone'
      });

    if (logError) {
      console.error('Database error:', logError);
      throw logError;
    }

    return NextResponse.json({
      success: true,
      fileId: clonedFile.data.id,
      fileName: clonedFile.data.name,
      size: Number(sourceFile.data.size || 0),
      webViewLink: webViewLink
    });

  } catch (error: any) {
    console.error('Clone error:', error);
    return NextResponse.json({ 
      error: error.message || 'Failed to clone file' 
    }, { status: 500 });
  }
} 
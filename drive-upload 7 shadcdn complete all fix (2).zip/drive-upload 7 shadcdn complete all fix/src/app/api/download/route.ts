import { NextRequest, NextResponse } from 'next/server';
import { DriveEncryption } from '@/lib/encryption';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const fileId = searchParams.get('file');
    const expiry = searchParams.get('expiry');
    const mac = searchParams.get('mac');

    if (!fileId || !expiry || !mac) {
      return NextResponse.json({ error: 'Invalid parameters' }, { status: 400 });
    }

    // Verify HMAC and expiry
    const isValid = await DriveEncryption.verifyLink(fileId, expiry, mac);
    if (!isValid) {
      return NextResponse.json({ error: 'Invalid or expired link' }, { status: 403 });
    }

    // Redirect to Google Drive download
    const downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${process.env.GOOGLE_API_KEY}`;
    return NextResponse.redirect(downloadUrl);

  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Download failed' }, { status: 500 });
  }
} 
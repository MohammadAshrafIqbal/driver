import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { google } from 'googleapis';
import { supabase } from '@/lib/supabase';

export async function DELETE(request: NextRequest) {
  const token = await getToken({ req: request });
  if (!token?.sub) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { fileId } = await request.json();
  
  try {
    // Get file details from Supabase
    const { data: file } = await supabase
      .from('file_logs')
      .select('*')
      .eq('id', fileId)
      .eq('user_id', token.sub)
      .single();

    if (!file) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }

    // Delete from Google Drive
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    try {
      // Check if file exists in Drive
      await drive.files.get({ fileId: file.file_id });
      // If exists, delete it
      await drive.files.delete({ fileId: file.file_id });
    } catch (driveError: any) {
      // If file doesn't exist in Drive, just continue with database deletion
      if (driveError.code !== 404) {
        throw driveError;
      }
    }

    // Delete from Supabase regardless of Drive status
    const { error: deleteError } = await supabase
      .from('file_logs')
      .delete()
      .eq('id', fileId)
      .eq('user_id', token.sub);

    if (deleteError) throw deleteError;

    // Update storage usage
    const send = (global as any).storageConnections?.get(token.sub);
    if (send) {
      send({ usedStorage: -file.size });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete error:', error);
    return NextResponse.json({ 
      error: 'Failed to delete file',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
} 
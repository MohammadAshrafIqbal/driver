import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { google } from 'googleapis';
import { Readable } from 'stream';
import { authOptions } from '../auth/[...nextauth]/route';
import { DriveEncryption } from '@/lib/encryption';

// Helper function to convert File to Stream
function bufferToStream(buffer: Buffer) {
  return new Readable({
    read() {
      this.push(buffer);
      this.push(null);
    }
  });
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file || !(file instanceof File)) {
      return NextResponse.json(
        { error: 'Invalid file provided' },
        { status: 400 }
      );
    }

    // Convert File to Buffer then to Stream
    const buffer = Buffer.from(await file.arrayBuffer());
    const stream = bufferToStream(buffer);

    // Set up Google Drive client
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    // Upload to Google Drive
    const response = await drive.files.create({
      requestBody: {
        name: file.name,
        mimeType: file.type,
      },
      media: {
        mimeType: file.type,
        body: stream,
      },
      fields: 'id',
    });

    // Get the file ID
    const fileId = response.data.id!;
    const baseUrl = request.headers.get('origin') || 'http://localhost:3000';
    const indexLink = await DriveEncryption.generateIndexLink(fileId, file.name, baseUrl);

    // Make file publicly accessible
    await drive.permissions.create({
      fileId,
      requestBody: {
        role: 'reader',
        type: 'anyone',
      },
    });

    return NextResponse.json({
      fileId: await DriveEncryption.encryptFileId(fileId),
      fileName: file.name,
      size: file.size,
      webViewLink: indexLink,
    });
  } catch (error) {
    console.error('Upload error:', error);
    if (error instanceof Error) {
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      );
    }
    return NextResponse.json(
      { error: 'Failed to upload file' },
      { status: 500 }
    );
  }
} 
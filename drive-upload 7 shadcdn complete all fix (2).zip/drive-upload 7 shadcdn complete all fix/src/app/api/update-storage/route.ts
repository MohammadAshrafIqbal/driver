import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';

export async function POST(request: NextRequest) {
  const token = await getToken({ req: request });
  const userId = token?.sub;
  
  if (!userId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { bytes } = await request.json();
  const send = (global as any).storageConnections?.get(userId);
  if (send) {
    send({ usedStorage: bytes });
  }

  return NextResponse.json({ success: true });
} 
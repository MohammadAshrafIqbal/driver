import { NextRequest, NextResponse } from 'next/server';
import { createHash } from 'crypto';
import { google } from 'googleapis';
import { DriveEncryption } from '@/lib/encryption';
import { supabase } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const { fileId, fileName } = await request.json();

    if (!fileId) {
      return NextResponse.json({ error: 'File ID is required' }, { status: 400 });
    }

    // Generate expiry timestamp (e.g., 1 hour from now)
    const expiry = Date.now() + 3600000; // 1 hour

    // Create HMAC for security
    const data = `file=${fileId}&expiry=${expiry}`;
    const hmac = createHash('sha256')
      .update(data + process.env.ENCRYPTION_KEY)
      .digest('hex');

    // Generate download URL
    const baseUrl = request.headers.get('origin') || 'http://localhost:3000';
    const downloadUrl = `${baseUrl}/api/download.aspx?file=${fileId}&expiry=${expiry}&mac=${hmac}`;

    return NextResponse.json({ url: downloadUrl });

  } catch (error) {
    console.error('Download URL generation error:', error);
    return NextResponse.json({ 
      error: 'Failed to generate download URL' 
    }, { status: 500 });
  }
}

// GET route for actual download
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const fileId = searchParams.get('file');
    const expiry = searchParams.get('expiry');
    const mac = searchParams.get('mac');
    const isShared = searchParams.get('shared') === 'true';

    if (!fileId || !expiry || !mac) {
      return NextResponse.json({ error: 'Invalid download parameters' }, { status: 400 });
    }

    // Verify expiry
    if (Date.now() > Number(expiry)) {
      return NextResponse.json({ error: 'Download link expired' }, { status: 410 });
    }

    // Verify HMAC
    const data = `file=${fileId}&expiry=${expiry}`;
    const expectedMac = createHash('sha256')
      .update(data + process.env.ENCRYPTION_KEY)
      .digest('hex');

    if (mac !== expectedMac) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
    }

    // Initialize Google Drive client
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    // If it's a shared file, increment view count
    if (isShared) {
      await supabase.rpc('increment_views', { 
        file_id: fileId 
      });
    }

    // Get file metadata
    const { data: file } = await drive.files.get({
      fileId,
      fields: 'id,name,mimeType,size',
      supportsAllDrives: true
    });

    // Get file content
    const response = await drive.files.get({
      fileId,
      alt: 'media',
      supportsAllDrives: true
    }, {
      responseType: 'stream'
    });

    const stream = new ReadableStream({
      start(controller) {
        response.data.on('data', (chunk: Buffer) => controller.enqueue(chunk));
        response.data.on('end', () => controller.close());
        response.data.on('error', (err: Error) => controller.error(err));
      }
    });

    // Return file stream
    return new Response(stream, {
      headers: {
        'Content-Type': file.mimeType || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${file.name}"`,
        'Transfer-Encoding': 'chunked'
      }
    });

  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Download failed' }, { status: 500 });
  }
} 
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';
import { google } from 'googleapis';
import { supabase } from '@/lib/supabase';
import { Readable } from 'stream';
import { checkAuth } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const session = await checkAuth();
  if (session instanceof NextResponse) return session;

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    // Convert File to Buffer
    const buffer = Buffer.from(await file.arrayBuffer());

    // Create readable stream
    const stream = new Readable();
    stream.push(buffer);
    stream.push(null);

    // Initialize Google Drive client
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );

    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    const driveResponse = await drive.files.create({
      requestBody: {
        name: file.name,
        parents: process.env.GOOGLE_DRIVE_FOLDER_ID ? [process.env.GOOGLE_DRIVE_FOLDER_ID] : undefined
      },
      media: {
        mimeType: file.type,
        body: stream
      },
      fields: 'id, name, size, webViewLink'
    });

    if (!driveResponse.data.id) {
      throw new Error('Failed to upload to Google Drive');
    }

    // Make file public
    await drive.permissions.create({
      fileId: driveResponse.data.id,
      requestBody: {
        role: 'reader',
        type: 'anyone'
      }
    });

    // Log to database
    const { error: dbError } = await supabase
      .from('file_logs')
      .insert({
        user_id: session.user.id,
        file_name: driveResponse.data.name,
        file_id: driveResponse.data.id,
        size: Number(driveResponse.data.size || 0),
        web_view_link: driveResponse.data.webViewLink,
        action_type: 'upload'
      });

    if (dbError) {
      console.error('Database error:', dbError);
      throw dbError;
    }

    return NextResponse.json({
      success: true,
      fileId: driveResponse.data.id,
      fileName: driveResponse.data.name,
      size: Number(driveResponse.data.size || 0),
      webViewLink: driveResponse.data.webViewLink
    });

  } catch (error: any) {
    console.error('Upload error:', error);
    return NextResponse.json({ 
      error: error.message || 'Upload failed' 
    }, { status: 500 });
  }
}

export const config = {
  api: {
    bodyParser: false
  }
}; 
'use client';

import { useSession } from 'next-auth/react';
import dynamic from 'next/dynamic';
import LandingPage from '@/components/LandingPage';

const DashboardStats = dynamic(() => import('@/components/DashboardStats'), {
  loading: () => <div className="animate-pulse h-32 bg-gray-100 dark:bg-gray-800 rounded-lg" />
});

export default function Dashboard() {
  const { data: session } = useSession();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
      {session && (
        <div className="pt-8 pb-12 px-4 sm:px-6 lg:px-8">
          <DashboardStats />
        </div>
      )}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <LandingPage />
      </div>
    </div>
  );
}

'use client';

import UploadSection from '@/components/UploadSection';
import DashboardStats from '@/components/DashboardStats';

export default function UploadPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <DashboardStats />
        <div className="mt-8">
          <UploadSection />
        </div>
      </div>
    </div>
  );
} 
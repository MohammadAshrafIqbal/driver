'use client';

import AuthGuard from '@/components/AuthGuard'
import MyFiles from '@/components/MyFiles'

export default function FilesPage() {
  return (
    <AuthGuard>
      <MyFiles />
    </AuthGuard>
  )
} 
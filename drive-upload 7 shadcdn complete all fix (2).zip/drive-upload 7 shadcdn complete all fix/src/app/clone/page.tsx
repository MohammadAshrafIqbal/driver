'use client';

import { useSession } from 'next-auth/react';
import CloneFile from '@/components/CloneFile';
import DashboardStats from '@/components/DashboardStats';
import Loading from '../loading';

export default function ClonePage() {
  const { data: session, status } = useSession();

  if (status === 'loading') return <Loading />;
  if (!session) return null;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <DashboardStats />
        <div className="mt-8 bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
          <CloneFile />
        </div>
      </div>
    </div>
  );
} 
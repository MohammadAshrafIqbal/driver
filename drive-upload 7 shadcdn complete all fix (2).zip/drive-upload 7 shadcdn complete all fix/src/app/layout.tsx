'use client';

import './globals.css';
import { Inter } from 'next/font/google';
import { NextAuthProvider } from './providers';
import { UploadsProvider } from '@/context/UploadsContext';
import Navbar from '@/components/Navbar';
import { Toaster } from "sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { useEffect, useState } from 'react';
import { Suspense } from 'react';
import PageTransition from '@/components/PageTransition';
import Loading from './loading';

const inter = Inter({ subsets: ['latin'] });

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Prevent flash of unstyled content
  if (!mounted) {
    return (
      <html lang="en" suppressHydrationWarning>
        <body>
          <div className="min-h-screen bg-background" />
        </body>
      </html>
    );
  }

  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <NextAuthProvider>
            <UploadsProvider>
              <Navbar />
              <Suspense fallback={<Loading />}>
                <PageTransition>
                  {children}
                </PageTransition>
              </Suspense>
              <Toaster />
            </UploadsProvider>
          </NextAuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}

import { NextRequest, NextResponse } from 'next/server';
import { createHash } from 'crypto';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const fileId = searchParams.get('file');
    const expiry = searchParams.get('expiry');
    const mac = searchParams.get('mac');

    if (!fileId || !expiry || !mac) {
      return NextResponse.json({ error: 'Invalid parameters' }, { status: 400 });
    }

    // Verify expiry
    const now = Date.now();
    if (now > parseInt(expiry)) {
      return NextResponse.json({ error: 'Link expired' }, { status: 403 });
    }

    // Verify HMAC
    const data = `file=${fileId}&expiry=${expiry}`;
    const expectedMac = createHash('sha256')
      .update(data + process.env.ENCRYPTION_KEY)
      .digest('hex');

    if (mac !== expectedMac) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
    }

    // Redirect to Google Drive download
    const driveUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${process.env.GOOGLE_API_KEY}`;
    
    return NextResponse.redirect(driveUrl);

  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Download failed' }, { status: 500 });
  }
} 
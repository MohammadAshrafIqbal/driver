'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { formatBytes, formatDate } from '@/lib/utils';
import { toast } from 'sonner';
import { 
  FiDownload, FiExternalLink, FiFile, FiClock, 
  FiHardDrive, FiShare2, FiCopy, FiCheckCircle 
} from 'react-icons/fi';
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { FileMetadata } from '@/types';

interface SharerData {
  fileId: string;
}

interface DownloadProgress {
  progress: number;
  downloaded: number;
  total: number;
}

function truncateFileName(fileName: string, maxLength: number = 15): string {
  if (fileName.length <= maxLength) return fileName;
  const extension = fileName.split('.').pop();
  const name = fileName.substring(0, maxLength - 4); // -4 for "..." and minimum extension length
  return `${name}...${extension}`;
}

function LoadingState() {
  return (
    <div className="p-6 space-y-4">
      <Skeleton className="h-12 w-12 rounded-lg" />
      <Skeleton className="h-4 w-2/3" />
      <Skeleton className="h-4 w-1/2" />
    </div>
  );
}

function ErrorState({ error }: { error: string | null }) {
  return (
    <div className="p-6 text-center">
      <div className="text-red-500 dark:text-red-400">
        {error || 'Failed to load file'}
      </div>
    </div>
  );
}

export default function SharerPage() {
  const { code } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fileData, setFileData] = useState<FileMetadata | null>(null);
  const [copying, setCopying] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgress>({
    progress: 0,
    downloaded: 0,
    total: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Get sharer data
        const sharerRes = await fetch(`/api/sharer/${code}`);
        if (!sharerRes.ok) throw new Error('Failed to fetch sharer data');
        const sharerData = await sharerRes.json();

        // Get file metadata
        const metadataRes = await fetch(`/api/drive/metadata?fileId=${sharerData.fileId}`);
        if (!metadataRes.ok) throw new Error('Failed to fetch file metadata');
        const metadata = await metadataRes.json();

        // Set download URL later when needed
        setData(metadata, sharerData, sharerData.webViewLink, setFileData);
      } catch (err) {
        console.error('Error:', err);
        setError(err instanceof Error ? err.message : 'Failed to load file');
      } finally {
        setLoading(false);
      }
    };

    if (code) {
      fetchData();
    }
  }, [code]);

  const handleCopyLink = async () => {
    try {
      setCopying(true);
      await navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard');
    } catch (err) {
      toast.error('Failed to copy link');
    } finally {
      setCopying(false);
    }
  };

  const handleDownload = async () => {
    if (!fileData) return;
    
    try {
      setDownloading(true);
      
      // Use the correct API endpoint and parameters
      const response = await fetch('/api/download.aspx', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          fileId: fileData.fileId,
          fileName: fileData.name,
          shared: true,
          webViewLink: fileData.webViewLink
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate download link');
      }

      const { url: downloadUrl } = await response.json();
      
      // Trigger download
      window.location.href = downloadUrl;

      toast.success('Download started');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to start download');
    } finally {
      setDownloading(false);
    }
  };

  const handleCopy = async (link: string) => {
    try {
      await navigator.clipboard.writeText(link);
      setCopying(true);
      toast.success('Link copied to clipboard');
      setTimeout(() => setCopying(false), 2000);
    } catch (error) {
      toast.error('Failed to copy link');
    }
  };

  if (loading) {
    return <LoadingSkeleton />;
  }

  if (error || !fileData) {
    return <ErrorState error={error} />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="max-w-md w-full">
        {loading ? (
          <LoadingState />
        ) : error ? (
          <ErrorState error={error} />
        ) : fileData && (
          <>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg flex items-center justify-center">
                  <FiFile className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <h1 className="text-xl font-semibold text-gray-900 dark:text-white truncate">
                    {truncateFileName(fileData.name)}
                  </h1>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {formatBytes(fileData.size)}
                  </p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* File Information Section */}
              <div className="space-y-3">
                <h2 className="text-sm font-medium text-gray-900 dark:text-white">
                  File Information
                </h2>
                <div className="grid gap-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Full Name</span>
                    <span className="text-gray-900 dark:text-white">{fileData.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Size</span>
                    <span className="text-gray-900 dark:text-white">
                      {formatBytes(fileData.size)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-4">
                <Button
                  className="flex-1"
                  onClick={handleDownload}
                  disabled={downloading}
                >
                  <FiDownload className="mr-2" />
                  Download
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open(fileData.driveUrl, '_blank')}
                >
                  <FiExternalLink className="mr-2" />
                  View
                </Button>
              </div>
            </CardContent>
          </>
        )}
      </Card>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader className="space-y-4">
          <Skeleton className="h-48 w-full rounded-lg" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-1/4" />
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          <Skeleton className="h-10 w-full" />
          <div className="flex gap-3 w-full">
            <Skeleton className="h-10 flex-1" />
            <Skeleton className="h-10 flex-1" />
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}

function setData(
  metadata: any, 
  sharerData: SharerData, 
  downloadUrl: string, 
  setFileData: (data: FileMetadata) => void
) {
  const fileData: FileMetadata = {
    id: metadata.id,
    fileId: sharerData.fileId,
    name: metadata.name,
    size: metadata.size,
    mimeType: metadata.mimeType,
    createdAt: metadata.createdAt || new Date().toISOString(),
    downloadUrl,
    driveUrl: `https://drive.google.com/file/d/${sharerData.fileId}/view`,
    thumbnailUrl: `https://drive.google.com/thumbnail?id=${sharerData.fileId}&sz=w1000`
  };
  setFileData(fileData);
} 
import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'

const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          prompt: "select_account"
        }
      }
    })
  ],
  secret: process.env.NEXTAUTH_SECRET,
  session: {
    strategy: 'jwt'
  },
  pages: {
    signIn: '/auth/login',
    error: '/auth/login'
  },
  callbacks: {
    async session({ session, token }) {
      if (session.user && token.sub) {
        session.user.id = token.sub;
      }
      return session;
    },
    async redirect({ url, baseUrl }) {
      return baseUrl;
    }
  }
};

export { authOptions };

export async function checkAuth() {
  const session = await getServerSession(authOptions)
  
  if (!session?.user) {
    return new NextResponse(
      JSON.stringify({ error: 'You must be logged in to access this endpoint' }),
      { status: 401 }
    )
  }
  
  return session
} 
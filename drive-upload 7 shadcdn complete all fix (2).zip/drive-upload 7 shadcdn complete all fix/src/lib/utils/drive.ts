export function extractFileId(url: string | null | undefined): string | null {
  try {
    // Return null if URL is not provided
    if (!url) return null;
    
    // Clean the URL
    const cleanUrl = url.trim();
    
    // Different URL patterns
    const patterns = [
      /\/file\/d\/([a-zA-Z0-9_-]{25,})/,  // Format: /file/d/FILE_ID/...
      /\?id=([a-zA-Z0-9_-]{25,})/,        // Format: ?id=FILE_ID
      /\/d\/([a-zA-Z0-9_-]{25,})/,        // Format: /d/FILE_ID/...
      /^([a-zA-Z0-9_-]{25,})$/            // Direct file ID
    ];

    // Try each pattern
    for (const pattern of patterns) {
      const match = cleanUrl.match(pattern);
      if (match && match[1]) return match[1];
    }

    // Last resort - try to find any 25+ character string that looks like a file ID
    const fallbackMatch = cleanUrl.match(/([a-zA-Z0-9_-]{25,})/);
    return fallbackMatch ? fallbackMatch[1] : null;

  } catch (error) {
    console.error('Error extracting file ID:', error);
    return null;
  }
} 
'use client';

import { useState, useCallback, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { formatBytes, calculateSpeed } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { useStorage } from '@/context/StorageContext';

export default function UploadFile() {
  const { data: session } = useSession();
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState(0);
  const [uploadedSize, setUploadedSize] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadStartTime = useRef<number>(0);
  const { updateStorage } = useStorage();

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) setFile(selectedFile);
  }, []);

  const uploadFile = async () => {
    if (!file) return;
    setUploading(true);
    setUploadProgress(0);
    setUploadSpeed(0);
    setUploadedSize(0);
    uploadStartTime.current = Date.now();

    const formData = new FormData();
    formData.append('file', file);

    try {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/upload-file');

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const progress = Math.round((event.loaded / event.total) * 100);
          const speed = calculateSpeed(event.loaded, uploadStartTime.current);
          setUploadProgress(progress);
          setUploadSpeed(speed);
          setUploadedSize(event.loaded);
        }
      };

      xhr.onload = async () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          await handleUploadSuccess(response);
          setFile(null);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
        setUploading(false);
      };

      xhr.send(formData);
    } catch (error) {
      console.error('Upload error:', error);
      setUploading(false);
    }
  };

  const handleUploadSuccess = async (response: any) => {
    try {
      await supabase.from('file_logs').insert({
        user_id: session?.user?.id,
        file_name: file!.name,
        file_id: response.fileId,
        size: file!.size,
        web_view_link: response.webViewLink,
        action_type: 'upload'
      });
      
      updateStorage(file!.size);
      window.dispatchEvent(new CustomEvent('fileUploaded'));
    } catch (error) {
      console.error('Error saving upload log:', error);
    }
  };

  return (
    <div className="space-y-4">
      <input
        type="file"
        onChange={handleFileSelect}
        className="block w-full text-sm text-gray-500 dark:text-gray-400
          file:mr-4 file:py-2 file:px-4
          file:rounded-full file:border-0
          file:text-sm file:font-semibold
          file:bg-indigo-50 file:text-indigo-700
          hover:file:bg-indigo-100
          dark:file:bg-gray-700 dark:file:text-gray-200
          dark:hover:file:bg-gray-600"
        ref={fileInputRef}
      />

      {file && (
        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Selected: {file.name}
            </p>
            <span className="text-xs px-2 py-1 rounded-full bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400">
              {formatBytes(file.size)}
            </span>
          </div>
        </div>
      )}

      {uploading && (
        <div className="space-y-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <span className="text-gray-600 dark:text-gray-300">
                {formatBytes(uploadedSize)} of {formatBytes(file?.size || 0)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                {formatBytes(uploadSpeed)}/s
              </span>
            </div>
          </div>

          <div className="relative h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${uploadProgress}%` }}
            >
              <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]" />
            </div>
          </div>

          <div className="flex justify-center">
            <span className="text-sm font-medium text-indigo-600 dark:text-indigo-400">
              {uploadProgress}%
            </span>
          </div>
        </div>
      )}

      <button
        onClick={uploadFile}
        disabled={!file || uploading}
        className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-all duration-300
          ${!file || uploading 
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 shadow-lg hover:shadow-indigo-500/25'
          }`}
      >
        {uploading ? 'Uploading...' : 'Upload to Drive'}
      </button>
    </div>
  );
} 
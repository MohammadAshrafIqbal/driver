'use client';

import { useState } from 'react';
import { useStorage } from '@/context/StorageContext';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

export default function FileUpload({ onSuccess }: { onSuccess: (driveLink: string) => void }) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { updateStorage } = useStorage();
  const { data: session, status } = useSession();
  const router = useRouter();

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    if (status !== 'authenticated') {
      router.push('/api/auth/signin');
      return;
    }
    
    setUploading(true);
    setError(null);
    const file = e.target.files[0];

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${session.accessToken}`
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Upload failed');
      }

      updateStorage(file.size);
      onSuccess(data.webViewLink);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
      {error && (
        <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg">
          {error}
        </div>
      )}
      <label className="block w-full">
        <input
          type="file"
          className="hidden"
          onChange={handleUpload}
          disabled={uploading || status !== 'authenticated'}
        />
        <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-indigo-500 dark:hover:border-indigo-400 transition-colors cursor-pointer">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
          </svg>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {uploading ? 'Uploading...' : 'Click to upload or drag and drop'}
          </p>
        </div>
      </label>
    </div>
  );
} 
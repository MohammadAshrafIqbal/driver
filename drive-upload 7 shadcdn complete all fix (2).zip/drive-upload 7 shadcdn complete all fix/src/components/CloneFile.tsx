'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useStorage } from '@/context/StorageContext';
import { FiCopy, FiExternalLink, FiCheck, FiDownload } from 'react-icons/fi';
import { formatBytes } from '@/lib/utils';

interface CloneResult {
  webViewLink: string;
  fileName: string;
  size: number;
  fileId: string;
}

interface DownloadProgress {
  progress: number;
  downloaded: number;
  total: number;
}

export default function CloneFile() {
  const { data: session } = useSession();
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const { updateStorage } = useStorage();
  const [cloneResult, setCloneResult] = useState<CloneResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgress | null>(null);

  const handleCopy = async (link: string) => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success('Link copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy link');
    }
  };

  const handleClone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) {
      toast.error('Please enter a Drive URL');
      return;
    }

    setLoading(true);
    setCloneResult(null);
    
    try {
      const response = await fetch('/api/clone', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ driveUrl: url }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to clone file');
      }

      updateStorage(data.size);
      setCloneResult({
        webViewLink: data.webViewLink,
        fileName: data.fileName,
        size: data.size,
        fileId: data.fileId
      });
      toast.success('File cloned successfully!');
      setUrl('');
    } catch (error: any) {
      toast.error(error.message || 'Failed to clone file');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!cloneResult) return;
    
    try {
      setDownloading(true);

      // First get the download URL from our API
      const response = await fetch('/api/download.aspx', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          fileId: cloneResult.fileId,
          fileName: cloneResult.fileName
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate download link');
      }

      const { url: downloadUrl } = await response.json();

      // Create download link and trigger download
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', cloneResult.fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Download started');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to start download');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Clone Drive File</CardTitle>
        <CardDescription>Enter a Google Drive file URL to clone</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleClone} className="space-y-4">
          <Input
            type="url"
            placeholder="https://drive.google.com/file/d/..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            disabled={loading}
          />
          <Button type="submit" disabled={loading || !url} className="w-full">
            {loading ? 'Cloning...' : 'Clone File'}
          </Button>
        </form>
      </CardContent>
      
      {cloneResult && (
        <CardFooter className="flex flex-col space-y-4">
          <div className="w-full p-4 rounded-lg bg-secondary">
            <div className="flex items-center justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-muted-foreground mb-1">
                  Cloned File Link
                </p>
                <p className="text-sm truncate">
                  {cloneResult.fileName}
                </p>
                {downloadProgress && (
                  <div className="mt-2 space-y-1">
                    <Progress value={downloadProgress.progress} className="h-1" />
                    <p className="text-xs text-muted-foreground">
                      {formatBytes(downloadProgress.downloaded)} of {formatBytes(downloadProgress.total)} 
                      ({downloadProgress.progress.toFixed(1)}%)
                    </p>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCopy(cloneResult.webViewLink)}
                  title="Copy link"
                  disabled={downloading}
                >
                  {copied ? (
                    <FiCheck className="h-4 w-4" />
                  ) : (
                    <FiCopy className="h-4 w-4" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleDownload}
                  title="Download file"
                  disabled={downloading}
                >
                  <FiDownload className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => window.open(cloneResult.webViewLink, '_blank')}
                  title="Open link"
                  disabled={downloading}
                >
                  <FiExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardFooter>
      )}
    </Card>
  );
} 
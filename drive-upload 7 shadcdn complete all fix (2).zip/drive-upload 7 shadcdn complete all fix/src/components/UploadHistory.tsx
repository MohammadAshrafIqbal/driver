'use client';

import { useState, useEffect, useCallback } from 'react';
import { formatBytes, formatDate } from '@/lib/utils';
import { useSession } from 'next-auth/react';
import { supabase } from '@/lib/supabase';
import { FileLog } from '@/types/supabase';
import { useStorage } from '@/context/StorageContext';
import DeleteModal from './DeleteModal';
import FileNavigation from './FileNavigation';

export default function UploadHistory() {
  const { data: session } = useSession();
  const [uploads, setUploads] = useState<FileLog[]>([]);
  const [copyStatus, setCopyStatus] = useState<Record<string, {
    sharer?: boolean;
    drive?: boolean;
  }>>({});
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    files: FileLog[];
  }>({ isOpen: false, files: [] });
  const { updateStorage } = useStorage();
  const [deleting, setDeleting] = useState<string | boolean | null>(null);

  useEffect(() => {
    if (session?.user?.id) {
      loadUploads();
      
      // Listen for new uploads
      const handleNewUpload = () => {
        loadUploads();
      };
      
      window.addEventListener('fileUploaded', handleNewUpload);
      return () => {
        window.removeEventListener('fileUploaded', handleNewUpload);
      };
    }
  }, [session?.user?.id]);

  async function loadUploads() {
    console.log('Loading uploads for user:', session?.user?.id); // Debug log
    const { data, error } = await supabase
      .from('file_logs')
      .select('*')
      .eq('user_id', session?.user?.id)
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Error loading uploads:', error);
      return;
    }

    if (data) {
      console.log('Loaded uploads:', data); // Debug log
      setUploads(data);
    }
  }

  const handleCopy = async (file: FileLog, type: 'sharer' | 'drive') => {
    try {
      let textToCopy = '';
      
      if (type === 'sharer') {
        if (!file.sharer_link) {
          const response = await fetch('/api/create-sharer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              driveUrl: file.web_view_link,
              fileName: file.file_name,
              fileSize: file.size
            })
          });

          if (!response.ok) {
            throw new Error('Failed to create sharer link');
          }

          const data = await response.json();
          textToCopy = data.url;
          await loadUploads();
        } else {
          textToCopy = file.sharer_link;
        }
      } else {
        textToCopy = file.web_view_link;
      }

      if (!textToCopy) {
        throw new Error('Link not available');
      }

      await navigator.clipboard.writeText(textToCopy);
      setCopyStatus(prev => ({
        ...prev,
        [file.id]: { ...prev[file.id], [type]: true }
      }));

      setTimeout(() => {
        setCopyStatus(prev => ({
          ...prev,
          [file.id]: { ...prev[file.id], [type]: false }
        }));
      }, 2000);
    } catch (error) {
      console.error('Copy error:', error);
    }
  };

  const handleDelete = async (fileId: string) => {
    try {
      if (!session?.user) {
        alert('Please sign in to delete files');
        return;
      }

      setDeleting('true');
      const response = await fetch(`/api/files/${fileId}`, {
        method: 'DELETE'
      });

      const data = await response.json();

      if (response.ok) {
        await loadUploads();
        setSelectedFiles(prev => prev.filter(id => id !== fileId));
      } else {
        alert(data.error || 'Failed to delete file');
      }
    } catch (error) {
      console.error('Delete error:', error);
      alert('Failed to delete file');
    } finally {
      setDeleting(null);
    }
  };

  const handleSelectAll = () => {
    if (selectedFiles.length === uploads.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(uploads.map(upload => upload.id));
    }
  };

  const handleSelect = (id: string) => {
    if (selectedFiles.includes(id)) {
      setSelectedFiles(selectedFiles.filter(fileId => fileId !== id));
    } else {
      setSelectedFiles([...selectedFiles, id]);
    }
  };

  const handleBulkDelete = async () => {
    try {
      setDeleting('true');
      const deletePromises = deleteModal.files.map(async (file) => {
        try {
          const response = await fetch(`/api/files/${file.id}`, {
            method: 'DELETE'
          });

          const data = await response.json();
          return response.ok;
        } catch (error) {
          console.error(`Error deleting file ${file.file_name}:`, error);
          return false;
        }
      });

      const results = await Promise.allSettled(deletePromises);
      const successCount = results.filter(
        result => result.status === 'fulfilled' && result.value
      ).length;

      if (successCount > 0) {
        await loadUploads();
        setSelectedFiles([]);
        alert(`Successfully deleted ${successCount} of ${deleteModal.files.length} files`);
      }

    } catch (error) {
      console.error('Bulk delete error:', error);
      alert('Failed to delete files');
    } finally {
      setDeleting(null);
      setDeleteModal({ isOpen: false, files: [] });
    }
  };

  if (uploads.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
        <p className="text-center text-gray-500 dark:text-gray-400">
          No uploads yet
        </p>
      </div>
    );
  }

  return (
    <div>
      <FileNavigation />
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 sm:mb-6 gap-4">
            <div className="flex items-center gap-4">
              <div 
                onClick={handleSelectAll}
                className={`w-5 h-5 rounded border-2 cursor-pointer transition-colors ${
                  selectedFiles.length === uploads.length
                    ? 'bg-indigo-500 border-indigo-500 dark:bg-indigo-400 dark:border-indigo-400'
                    : 'border-gray-300 dark:border-gray-600'
                }`}
              >
                {selectedFiles.length === uploads.length && (
                  <svg className="w-full h-full text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>

              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800 dark:text-white">
                  {selectedFiles.length > 0 ? `Selected ${selectedFiles.length} files` : 'Recent Uploads'}
                </h2>
                {selectedFiles.length === 0 && (
                  <span className="text-sm text-gray-500 dark:text-gray-400">({uploads.length})</span>
                )}
              </div>
            </div>

            {selectedFiles.length > 0 && (
              <button
                onClick={() => setSelectedFiles([])}
                className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              >
                Clear selection
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    <input
                      type="checkbox"
                      checked={selectedFiles.length === uploads.length}
                      onChange={handleSelectAll}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    File Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Size
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {uploads.map((file) => (
                  <tr key={file.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedFiles.includes(file.id)}
                        onChange={() => handleSelect(file.id)}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="px-4 sm:px-6 py-4">
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-xs">
                          {file.file_name}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {formatBytes(file.size)}
                      </span>
                    </td>
                    <td className="px-4 sm:px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {formatDate(new Date(file.created_at).getTime())}
                      </span>
                    </td>
                    <td className="px-4 sm:px-6 py-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => handleCopy(file, 'sharer')}
                          className="flex items-center gap-1 px-3 py-1 text-sm text-gray-700 dark:text-gray-200 
                                   hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          {copyStatus[file.id]?.sharer ? (
                            <>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                              </svg>
                              <span>Download Link</span>
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleCopy(file, 'drive')}
                          className="flex items-center gap-1 px-3 py-1 text-sm text-gray-700 dark:text-gray-200 
                                   hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          {copyStatus[file.id]?.drive ? (
                            <>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                              </svg>
                              <span>Drive Link</span>
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleDelete(file.id)}
                          className="flex items-center gap-1 px-3 py-1 text-sm text-red-600 dark:text-red-400 
                                   hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {selectedFiles.length > 0 && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-white dark:bg-gray-800 rounded-full shadow-lg px-6 py-3 border border-gray-200 dark:border-gray-700">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
              {selectedFiles.length} selected
            </span>
            <div className="w-px h-6 bg-gray-200 dark:bg-gray-700" />
            <button
              onClick={handleBulkDelete}
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Delete Selected
            </button>
          </div>
        )}

        <DeleteModal
          isOpen={deleteModal.isOpen}
          files={deleteModal.files}
          onConfirm={() => {
            handleBulkDelete();
            setDeleteModal({ isOpen: false, files: [] });
          }}
          onCancel={() => setDeleteModal({ isOpen: false, files: [] })}
        />
      </div>
    </div>
  );
} 
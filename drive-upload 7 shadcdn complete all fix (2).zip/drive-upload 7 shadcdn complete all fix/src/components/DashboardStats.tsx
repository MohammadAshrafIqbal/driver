'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { formatBytes } from '@/lib/utils';
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { 
  FiHardDrive, 
  FiZap, 
  FiTrendingUp, 
  FiArrowUp, 
  FiArrowDown,
  FiCloud
} from 'react-icons/fi';
import { supabase } from '@/lib/supabase';

const STORAGE_LIMIT = 107374182400; // 100GB in bytes

export default function DashboardStats() {
  const { data: session } = useSession();
  const [storageUsed, setStorageUsed] = useState(0);
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    async function fetchStorageUsed() {
      if (!session?.user?.id) return;
      try {
        const { data: files, error } = await supabase
          .from('file_logs')
          .select('size')
          .eq('user_id', session.user.id);

        if (error) throw error;
        const totalUsed = files?.reduce((acc, file) => acc + (file.size || 0), 0) || 0;
        setStorageUsed(totalUsed);
      } catch (error) {
        console.error('Error fetching storage usage:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchStorageUsed();
  }, [session?.user?.id]);

  if (!mounted) return null;

  const usagePercentage = (storageUsed / STORAGE_LIMIT) * 100;
  const available = STORAGE_LIMIT - storageUsed;

  if (loading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse bg-card/50">
            <CardContent className="p-6">
              <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Main Storage Card */}
      <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 text-white shadow-xl">
        <div className="absolute inset-0 bg-black/10" />
        <div className="absolute top-0 right-0 p-6">
          <FiCloud className="h-24 w-24 opacity-20" />
        </div>
        <CardContent className="relative p-8">
          <div className="grid gap-8 md:grid-cols-3">
            {/* Storage Used */}
            <div className="backdrop-blur-sm bg-white/10 rounded-2xl p-4">
              <p className="text-sm font-medium text-white/80">Storage Used</p>
              <p className="text-3xl font-bold mt-2">{formatBytes(storageUsed)}</p>
            </div>

            {/* Storage Available */}
            <div className="backdrop-blur-sm bg-white/10 rounded-2xl p-4">
              <p className="text-sm font-medium text-white/80">Available</p>
              <p className="text-3xl font-bold mt-2">{formatBytes(available)}</p>
            </div>

            {/* Usage Percentage */}
            <div className="backdrop-blur-sm bg-white/10 rounded-2xl p-4">
              <p className="text-sm font-medium text-white/80">Usage</p>
              <p className="text-3xl font-bold mt-2">{usagePercentage.toFixed(1)}%</p>
            </div>
          </div>

          <div className="mt-8">
            <Progress value={usagePercentage} className="h-3 bg-white/20" />
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-3">
        {/* Upload Speed Card */}
        <Card className="group hover:scale-[1.02] transition-transform duration-300 border-0 bg-gradient-to-br from-blue-500 to-cyan-400 text-white shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-white/80">Upload Speed</p>
                <h3 className="text-2xl font-bold">Unlimited</h3>
              </div>
              <div className="rounded-full bg-white/20 p-3 group-hover:scale-110 transition-transform duration-300">
                <FiArrowUp className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center gap-2 text-sm text-white/80">
                <FiTrendingUp className="h-4 w-4" />
                <span>No Speed Limit</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Download Speed Card */}
        <Card className="group hover:scale-[1.02] transition-transform duration-300 border-0 bg-gradient-to-br from-green-500 to-emerald-400 text-white shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-white/80">Download Speed</p>
                <h3 className="text-2xl font-bold">Unlimited</h3>
              </div>
              <div className="rounded-full bg-white/20 p-3 group-hover:scale-110 transition-transform duration-300">
                <FiArrowDown className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center gap-2 text-sm text-white/80">
                <FiTrendingUp className="h-4 w-4" />
                <span>High Speed</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Storage Type Card */}
        <Card className="group hover:scale-[1.02] transition-transform duration-300 border-0 bg-gradient-to-br from-purple-500 to-violet-400 text-white shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-white/80">Storage Type</p>
                <h3 className="text-2xl font-bold">Premium</h3>
              </div>
              <div className="rounded-full bg-white/20 p-3 group-hover:scale-110 transition-transform duration-300">
                <FiHardDrive className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center gap-2 text-sm text-white/80">
                <FiTrendingUp className="h-4 w-4" />
                <span>High Reliability</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
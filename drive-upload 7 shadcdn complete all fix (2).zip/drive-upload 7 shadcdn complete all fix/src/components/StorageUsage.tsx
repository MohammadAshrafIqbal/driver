'use client';

import { useStorage } from '@/context/StorageContext';
import { formatBytes } from '@/lib/utils';

export default function StorageUsage() {
  const { storage } = useStorage();
  const usagePercentage = (storage.used / storage.total) * 100;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Storage Usage</h2>
        <span className="text-sm text-gray-500 dark:text-gray-400">
          {formatBytes(storage.used)} / {formatBytes(storage.total)}
        </span>
      </div>
      
      <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-indigo-600 dark:bg-indigo-500 transition-all duration-500"
          style={{ width: `${Math.min(usagePercentage, 100)}%` }}
        />
      </div>
    </div>
  );
} 
'use client';

import { useState, useEffect } from 'react';
import { formatBytes, formatDate } from '@/lib/utils';
import { useSession } from 'next-auth/react';
import { supabase } from '@/lib/supabase';
import { FileLog } from '@/types/supabase';
import { useStorage } from '@/context/StorageContext';
import DeleteModal from './DeleteModal';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  FileIcon,
  MoreHorizontalIcon,
  CopyIcon,
  ExternalLinkIcon,
  TrashIcon,
  DownloadIcon,
  CheckIcon,
} from "lucide-react";
import { toast } from "sonner";

export default function MyFiles() {
  const { data: session } = useSession();
  const [files, setFiles] = useState<FileLog[]>([]);
  const [copyStatus, setCopyStatus] = useState<Record<string, {
    drive?: boolean;
    index?: boolean;
  }>>({});
  const { updateStorage } = useStorage();
  const [deleting, setDeleting] = useState<string | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; files: FileLog[] }>({
    isOpen: false,
    files: []
  });
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());

  // Add selection handlers
  const toggleSelection = (id: string) => {
    setSelectedFiles(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (selectedFiles.size === files.length) {
      setSelectedFiles(new Set());
    } else {
      setSelectedFiles(new Set(files.map(file => file.id)));
    }
  };

  const clearSelection = () => setSelectedFiles(new Set());

  // Add bulk actions
  const handleBulkCopy = async (type: 'drive' | 'index') => {
    const links = files
      .filter(file => selectedFiles.has(file.id))
      .map(file => type === 'drive' 
        ? `https://drive.google.com/file/d/${file.file_id}/view`
        : file.web_view_link
      )
      .join('\n');
    
    await navigator.clipboard.writeText(links);
    clearSelection();
  };

  const handleBulkDelete = async () => {
    const filesToDelete = files.filter(file => selectedFiles.has(file.id));
    
    for (const file of filesToDelete) {
      await handleDelete(file);
    }
    
    clearSelection();
  };

  // Add after state declarations
  const handleDelete = async (file: FileLog) => {
    setDeleting(file.id);
    try {
      const response = await fetch(`/api/files/${file.id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to delete file');
      }

      // Remove file from UI
      setFiles(prev => prev.filter(f => f.id !== file.id));
      
      // Update storage if needed
      if (updateStorage) {
        updateStorage(-file.size);
      }

      // Close modal if open
      setDeleteModal({ isOpen: false, files: [] });

    } catch (error) {
      console.error('Delete error:', error);
      alert(error instanceof Error ? error.message : 'Failed to delete file');
    } finally {
      setDeleting(null);
    }
  };

  // Add handleCopy function after handleDelete
  const handleCopy = async (link: string, id: string, type: 'drive' | 'index') => {
    await navigator.clipboard.writeText(link);
    setCopyStatus(prev => ({
      ...prev,
      [id]: { ...prev[id], [type]: true }
    }));
    setTimeout(() => {
      setCopyStatus(prev => ({
        ...prev,
        [id]: { ...prev[id], [type]: false }
      }));
    }, 2000);
  };

  // Add handleDownload function after handleCopy
  const handleDownload = async (file: FileLog) => {
    try {
      const response = await fetch(`/api/download/${file.file_id}?filename=${file.file_name}`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.file_name;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      toast.error('Failed to download file');
    }
  };

  // Add loadFiles function after state declarations
  useEffect(() => {
    if (session?.user?.id) {
      loadFiles();
    }
  }, [session?.user?.id]);

  async function loadFiles() {
    const { data, error } = await supabase
      .from('file_logs')
      .select('*')
      .eq('user_id', session?.user?.id)
      .order('created_at', { ascending: false });

    if (data) {
      setFiles(data);
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold tracking-tight">My Files</h1>
        <p className="text-muted-foreground mt-2">
          Manage all your uploaded, cloned, and shared files
        </p>
      </div>

      <Card className="w-full shadow-lg border border-border/40 bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <CardHeader className="flex flex-row items-center justify-between border-b">
          <div className="space-y-1.5">
            <CardTitle className="text-2xl font-semibold leading-none tracking-tight">
              Files
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {files.length} file{files.length !== 1 && 's'} total
            </p>
          </div>
        {selectedFiles.size > 0 && (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => handleBulkDelete()}
              className="flex items-center gap-2"
            >
              <TrashIcon className="h-4 w-4" />
              Delete Selected ({selectedFiles.size})
            </Button>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[calc(100vh-350px)]">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={files.length > 0 && selectedFiles.size === files.length}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedFiles(new Set(files.map(f => f.id)));
                        } else {
                          setSelectedFiles(new Set());
                        }
                      }}
                    />
                  </TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
          {files.map((file) => (
                  <TableRow key={file.id} className="group">
                    <TableCell>
                      <Checkbox
                        checked={selectedFiles.has(file.id)}
                        onCheckedChange={(checked) => toggleSelection(file.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="rounded-lg p-2 bg-primary/5 text-primary">
                          <FileIcon className="h-4 w-4" />
                </div>
                        <div className="flex flex-col">
                          <span className="font-medium truncate max-w-[200px]">
                {file.file_name}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            ID: {file.file_id}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium">{formatBytes(file.size)}</span>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={file.action_type === 'upload' ? 'default' : 
                               file.action_type === 'clone' ? 'secondary' : 'outline'} 
                        className="capitalize"
                      >
                        {file.action_type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {formatDate(file.created_at)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <MoreHorizontalIcon className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleCopy(file.file_id, file.id, 'drive')}>
                            <CopyIcon className="mr-2 h-4 w-4" />
                            Copy ID
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => window.open(file.web_view_link, '_blank')}>
                            <ExternalLinkIcon className="mr-2 h-4 w-4" />
                            Open Link
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownload(file)}>
                            <DownloadIcon className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDelete(file)}
                            className="text-red-600 focus:text-red-600 dark:text-red-400 dark:focus:text-red-400"
                          >
                            <TrashIcon className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>

          {files.length === 0 && (
            <div className="flex flex-col items-center justify-center h-[400px] text-center px-4">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <FileIcon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">No files yet</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Upload your first file to get started. You can upload, clone, or share files here.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <DeleteModal
        isOpen={deleteModal.isOpen}
        files={deleteModal.files}
        onConfirm={() => {
          handleBulkDelete();
          setDeleteModal({ isOpen: false, files: [] });
        }}
        onCancel={() => setDeleteModal({ isOpen: false, files: [] })}
      />
    </div>
  );
} 
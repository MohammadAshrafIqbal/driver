'use client';

import { useState, useRef } from 'react';
import { useStorage } from '@/context/StorageContext';
import { motion, AnimatePresence } from 'framer-motion';
import { formatBytes, calculateSpeed } from '@/lib/utils';
import { FiUploadCloud, FiX, FiCopy, FiExternalLink, FiCheck, FiFile } from 'react-icons/fi';
import axios from 'axios';

interface UploadResponse {
  success: boolean;
  webViewLink: string;
  sharerLink: string;
}

interface UploadProgress {
  loaded: number;
  total: number;
  progress: number;
  rate: number;
  estimated: number;
}

interface UploadStatus {
  file: File;
  fileSize: number;
  progress: number;
  speed: number;
  uploaded: number;
  estimated: number;
  status: 'waiting' | 'uploading' | 'success' | 'error';
  error?: string;
  cancelToken?: AbortController;
  startTime?: number;
  webViewLink?: string;
  sharerLink?: string;
}

export default function UploadSection() {
  const [uploads, setUploads] = useState<Record<string, UploadStatus>>({});
  const [copyStatus, setCopyStatus] = useState<Record<string, 'drive' | 'sharer' | null>>({});
  const { updateStorage } = useStorage();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (files: FileList) => {
    const newUploads: Record<string, UploadStatus> = {};
    
    Array.from(files).forEach(file => {
      newUploads[file.name] = {
        file,
        fileSize: file.size,
        progress: 0,
        speed: 0,
        uploaded: 0,
        estimated: 0,
        status: 'waiting',
        cancelToken: new AbortController(),
        startTime: Date.now()
      };
    });

    setUploads(prev => ({ ...prev, ...newUploads }));

    // Upload files in parallel
    await Promise.all(
      Object.entries(newUploads).map(([fileName, status]) => 
        uploadFile(fileName, status)
      )
    );
  };

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const uploadFile = async (fileName: string, status: UploadStatus) => {
    const formData = new FormData();
    formData.append('file', status.file);

    try {
      setUploads(prev => ({
        ...prev,
        [fileName]: { ...prev[fileName], status: 'uploading' }
      }));

      const source = axios.CancelToken.source();
      status.cancelToken!.signal.addEventListener('abort', () => source.cancel());

      const startTime = Date.now();
      let lastLoaded = 0;
      let lastTime = startTime;

      const { data } = await axios.post('/api/upload', formData, {
        cancelToken: source.token,
        onUploadProgress: (progressEvent) => {
          const total = (progressEvent as any).total || progressEvent.loaded;
          const currentTime = Date.now();
          const timeElapsed = (currentTime - lastTime) / 1000;
          const loadedDelta = progressEvent.loaded - lastLoaded;
          
          const currentRate = timeElapsed > 0 ? loadedDelta / timeElapsed : 0;
          const progress = (progressEvent.loaded / total) * 100;
          const remaining = progress < 100 
            ? ((total - progressEvent.loaded) / currentRate)
            : 0;

          setUploads(prev => ({
            ...prev,
            [fileName]: {
              ...prev[fileName],
              progress,
              speed: currentRate,
              uploaded: progressEvent.loaded,
              estimated: remaining
            }
          }));

          lastLoaded = progressEvent.loaded;
          lastTime = currentTime;
        }
      });

      setUploads(prev => ({
        ...prev,
        [fileName]: { 
          ...prev[fileName], 
          status: 'success',
          progress: 100,
          webViewLink: data.webViewLink,
          sharerLink: data.sharerLink
        }
      }));

      updateStorage(status.fileSize);

    } catch (error: unknown) {
      if (axios.isCancel(error)) {
        setUploads(prev => {
          const { [fileName]: _, ...rest } = prev;
          return rest;
        });
      } else {
        setUploads(prev => ({
          ...prev,
          [fileName]: {
            ...prev[fileName],
            status: 'error',
            error: error instanceof Error ? error.message : 'Upload failed'
          }
        }));
      }
    }
  };

  const cancelUpload = (fileName: string) => {
    const upload = uploads[fileName];
    if (upload?.cancelToken) {
      upload.cancelToken.abort();
      setUploads(prev => {
        const { [fileName]: _, ...rest } = prev;
        return rest;
      });
    }
  };

  const handleCopy = async (link: string, fileName: string, type: 'drive' | 'sharer') => {
    await navigator.clipboard.writeText(link);
    setCopyStatus(prev => ({ ...prev, [fileName]: type }));
    setTimeout(() => {
      setCopyStatus(prev => ({ ...prev, [fileName]: null }));
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div 
        className="relative border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl p-10 
          transition-all duration-300 hover:border-indigo-500 dark:hover:border-indigo-400
          bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900
          cursor-pointer group"
        onClick={handleClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <input
          type="file"
          ref={inputRef}
          multiple
          className="hidden"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
        
        <div className="text-center">
          <div className="relative inline-flex">
            <FiUploadCloud className="h-16 w-16 text-indigo-500 dark:text-indigo-400 
              transition-transform duration-300 group-hover:scale-110" />
            <motion.div
              className="absolute inset-0"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <FiUploadCloud className="h-16 w-16 text-indigo-500 dark:text-indigo-400 opacity-50" />
            </motion.div>
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-white">
            Drop files here or click to upload
          </h3>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
            Support for multiple files
          </p>
        </div>
      </div>

      <AnimatePresence>
        {Object.entries(uploads).map(([fileName, status]) => (
          <motion.div
            key={fileName}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl">
                <FiFile className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-base font-medium text-gray-900 dark:text-white truncate">
                  {fileName}
                </h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {formatBytes(status.fileSize)}
                </p>
              </div>
              
              {status.status === 'uploading' && (
                <button
                  onClick={() => cancelUpload(fileName)}
                  className="p-2 text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400
                    transition-colors duration-200"
                >
                  <FiX className="h-5 w-5" />
                </button>
              )}
            </div>

            {status.status === 'uploading' && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span>{Math.round(status.progress)}%</span>
                  <div className="flex gap-4">
                    <span>{formatBytes(status.speed)}/s</span>
                    <span>
                      {status.estimated > 60
                        ? `${Math.round(status.estimated / 60)}m remaining`
                        : `${Math.round(status.estimated)}s remaining`}
                    </span>
                  </div>
                </div>
                <div className="relative h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="absolute h-full bg-gradient-to-r from-indigo-500 to-indigo-600 
                      transition-all duration-300"
                    style={{ width: `${status.progress}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]" />
                  </div>
                </div>
              </div>
            )}

            {status.status === 'error' && (
              <div className="mt-2 p-4 bg-red-50 dark:bg-red-900/20 rounded-xl">
                <p className="text-sm text-red-600 dark:text-red-400">
                  {status.error}
                </p>
              </div>
            )}

            {status.status === 'success' && (
              <div className="mt-4 space-y-3">
                {[
                  { type: 'drive' as const, label: 'Drive Link', link: status.webViewLink },
                  { type: 'sharer' as const, label: 'Sharer Link', link: status.sharerLink }
                ].map(({ type, label, link }) => (
                  <div key={type} className="flex items-center justify-between gap-4 p-3 
                    bg-gray-50 dark:bg-gray-700/50 rounded-xl group hover:bg-gray-100 
                    dark:hover:bg-gray-700 transition-colors duration-200">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{label}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{link}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopy(link || '', fileName, type)}
                        className="p-2 text-gray-500 hover:text-indigo-500 dark:text-gray-400 
                          dark:hover:text-indigo-400 transition-colors duration-200"
                      >
                        {copyStatus[fileName] === type ? (
                          <FiCheck className="h-5 w-5" />
                        ) : (
                          <FiCopy className="h-5 w-5" />
                        )}
                      </button>
                      <a
                        href={link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 text-gray-500 hover:text-indigo-500 dark:text-gray-400 
                          dark:hover:text-indigo-400 transition-colors duration-200"
                      >
                        <FiExternalLink className="h-5 w-5" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
} 
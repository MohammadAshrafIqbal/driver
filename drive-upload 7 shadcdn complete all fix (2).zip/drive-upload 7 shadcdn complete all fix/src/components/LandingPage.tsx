'use client';

import { useSession } from 'next-auth/react';

export default function LandingPage() {
  const { data: session } = useSession();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Features of Latest DriveShare
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">
          {session ? 'Welcome back! Here are the features you can use:' : 'Sign in to access all these features:'}
        </p>
      </div>

      <div className="mb-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl shadow-xl overflow-hidden">
        <div className="px-6 py-8 md:px-12 md:py-10 flex flex-col md:flex-row items-center justify-between">
          <div className="text-white mb-6 md:mb-0">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">Need Premium Access?</h2>
            <p className="text-blue-100 text-lg">
              Contact our Telegram support for premium account access
            </p>
          </div>
          <a
            href="https://t.me/Drive_seller"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-blue-600 bg-white hover:bg-blue-50 transition-colors duration-150 shadow-md hover:shadow-lg"
          >
            <svg 
              className="w-5 h-5 mr-2" 
              fill="currentColor" 
              viewBox="0 0 24 24"
            >
              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18.717-.962 3.767-1.362 5.502-.168.728-.319 1.345-.455 1.892-.137.547-.253.911-.349 1.092-.095.181-.209.367-.342.461-.095.066-.19.092-.285.077a.936.936 0 01-.342-.121c-.209-.137-1.094-.715-2.655-1.734-.19-.137-.285-.214-.285-.231 0-.033.019-.066.057-.099 1.094-1.065 2.369-2.303 2.369-2.303.057-.057.095-.137.114-.238.019-.1-.038-.181-.17-.243-.057-.033-1.075-.749-3.053-2.147-.549-.386-.834-.6-.853-.643-.057-.115-.019-.214.114-.296.247-.148 2.636-1.012 3.558-1.37.871-.337 1.075-.41 1.246-.41.038 0 .133.019.285.055.095.033.171.1.228.198.038.066.057.148.057.243-.019.082-.019.164 0 .247z"/>
            </svg>
            Contact on Telegram
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Storage Feature */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12V8H4v4m16 0v4H4v-4m16 0H4" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Unlimited Storage</h3>
          <p className="text-gray-600 dark:text-gray-400">
            No space limitations—upload and store as many files as you need.
          </p>
        </div>

        {/* File Management */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Advanced File Management</h3>
          <ul className="text-gray-600 dark:text-gray-400 list-disc list-inside space-y-1">
            <li>Clone files effortlessly</li>
            <li>Share files securely</li>
            <li>Upload with ease</li>
          </ul>
        </div>

        {/* Security */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Reliable and Secure</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Your files are stored safely, ensuring privacy and data protection.
          </p>
        </div>

        {/* Collaboration */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Collaboration-Friendly</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Share and manage files easily for better teamwork and efficiency.
          </p>
        </div>

        {/* Scalability */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-yellow-600 dark:text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Scalability</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Perfect for both personal and business use, adapting to your growing needs.
          </p>
        </div>

        {/* No Domain Issues */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center mb-4">
            <svg className="w-6 h-6 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No Domain Issues</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Enjoy uninterrupted access without worrying about domain-related problems.
          </p>
        </div>
      </div>

      <div className="mt-12 text-center space-y-4">
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Our service combines convenience, reliability, and scalability, making it an all-in-one solution for hassle-free file hosting.
        </p>
        <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
          <span>Need help?</span>
          <a
            href="https://t.me/Drive_seller"
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 flex items-center"
          >
            <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18.717-.962 3.767-1.362 5.502-.168.728-.319 1.345-.455 1.892-.137.547-.253.911-.349 1.092-.095.181-.209.367-.342.461-.095.066-.19.092-.285.077a.936.936 0 01-.342-.121c-.209-.137-1.094-.715-2.655-1.734-.19-.137-.285-.214-.285-.231 0-.033.019-.066.057-.099 1.094-1.065 2.369-2.303 2.369-2.303.057-.057.095-.137.114-.238.019-.1-.038-.181-.17-.243-.057-.033-1.075-.749-3.053-2.147-.549-.386-.834-.6-.853-.643-.057-.115-.019-.214.114-.296.247-.148 2.636-1.012 3.558-1.37.871-.337 1.075-.41 1.246-.41.038 0 .133.019.285.055.095.033.171.1.228.198.038.066.057.148.057.243-.019.082-.019.164 0 .247z"/>
            </svg>
            @Drive_seller
          </a>
        </div>
      </div>
    </div>
  );
} 
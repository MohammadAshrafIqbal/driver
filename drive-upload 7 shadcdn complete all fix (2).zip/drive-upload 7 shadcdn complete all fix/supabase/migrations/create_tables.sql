-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing tables if they exist
DROP TABLE IF EXISTS public.sharer_links CASCADE;
DROP TABLE IF EXISTS public.file_logs CASCADE;

-- Create file_logs table first
CREATE TABLE IF NOT EXISTS public.file_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_id TEXT NOT NULL UNIQUE,
  size BIGINT NOT NULL,
  web_view_link TEXT NOT NULL,
  action_type VARCHAR(10) NOT NULL CHECK (action_type IN ('upload', 'clone', 'share')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create sharer_links table with foreign key
CREATE TABLE IF NOT EXISTS public.sharer_links (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  file_id TEXT NOT NULL REFERENCES public.file_logs(file_id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  views INTEGER DEFAULT 0,
  is_public BOOLEAN DEFAULT true
);

-- Create indexes
CREATE INDEX idx_file_logs_user_id ON file_logs(user_id);
CREATE INDEX idx_file_logs_file_id ON file_logs(file_id);
CREATE INDEX idx_sharer_links_code ON sharer_links(code);
CREATE INDEX idx_sharer_links_file_id ON sharer_links(file_id);
CREATE INDEX idx_sharer_links_user_id ON sharer_links(user_id);

-- Enable RLS
ALTER TABLE file_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sharer_links ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for file_logs
CREATE POLICY "Users can view their own files"
  ON file_logs FOR SELECT
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can insert their own files"
  ON file_logs FOR INSERT
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own files"
  ON file_logs FOR UPDATE
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can delete their own files"
  ON file_logs FOR DELETE
  USING (auth.uid()::text = user_id);

-- Create RLS policies for sharer_links
CREATE POLICY "Users can view their own sharer links"
  ON sharer_links FOR SELECT
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can insert their own sharer links"
  ON sharer_links FOR INSERT
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own sharer links"
  ON sharer_links FOR UPDATE
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can delete their own sharer links"
  ON sharer_links FOR DELETE
  USING (auth.uid()::text = user_id);

-- Add public access policies
CREATE POLICY "Allow public access to sharer links"
  ON public.sharer_links
  FOR SELECT
  USING (true);

CREATE POLICY "Allow public access to shared files"
  ON public.file_logs
  FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.sharer_links
    WHERE sharer_links.file_id = file_logs.file_id
  ));

-- Create sharing function
CREATE OR REPLACE FUNCTION public.create_sharer_link(
  p_user_id TEXT,
  p_drive_file_id TEXT,
  p_file_name TEXT,
  p_file_size BIGINT,
  p_web_view_link TEXT,
  p_code TEXT,
  p_sharer_link TEXT
) RETURNS json AS $$
DECLARE
  v_file_id TEXT;
  v_sharer_id UUID;
BEGIN
  -- First, create or get file log
  INSERT INTO public.file_logs (
    user_id,
    file_id,
    file_name,
    size,
    web_view_link,
    action_type
  ) VALUES (
    p_user_id,
    p_drive_file_id,
    p_file_name,
    p_file_size,
    p_web_view_link,
    'share'
  )
  ON CONFLICT (file_id) DO NOTHING
  RETURNING file_id INTO v_file_id;

  -- If no file_id was returned, get it from existing record
  IF v_file_id IS NULL THEN
    SELECT file_id INTO v_file_id
    FROM public.file_logs
    WHERE file_id = p_drive_file_id;
  END IF;

  -- Create sharer link
  INSERT INTO public.sharer_links (
    code,
    file_id,
    user_id
  ) VALUES (
    p_code,
    v_file_id,
    p_user_id
  )
  RETURNING id INTO v_sharer_id;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'code', p_code,
    'url', p_sharer_link
  );
END;
$$ LANGUAGE plpgsql; 
// Import your existing worker code configuration
const authConfig = {
  "client_id": "296161728541-euvu4bnl1qht77qmc7re0f1vqqt29iq5.apps.googleusercontent.com",
  "client_secret": "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",
  "refresh_token": "1//04ntreTb1iBvrCgYIARAAGAQSNwF-L9Ir1J2S2Df9r6_sRRtrWkv4itXuFWjCU8jEv-FRSBZ9xgZh1qrCssPA3gIP5pwu5iokoeU",
  // ... rest of your auth config
};

self.addEventListener('message', async (e) => {
  const { action, fileId, fileName } = e.data;

  if (action === 'index') {
    try {
      // Use your existing worker logic to generate the index link
      const downloadUrl = await generateIndexLink(fileId);
      
      self.postMessage({
        url: downloadUrl,
        fileName,
        success: true
      });
    } catch (error) {
      self.postMessage({ error: error.message });
    }
  }
});

async function generateIndexLink(fileId) {
  // Your existing index link generation logic
  const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?key=${authConfig.api_key}`, {
    headers: {
      'Authorization': `Bearer ${authConfig.access_token}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to access file');
  }

  // Generate your index link using your existing logic
  return `${self.location.origin}/d/${fileId}`;
}

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  
  if (url.pathname.startsWith('/download.aspx')) {
    event.respondWith(handleEncryptedDownload(event.request));
  }
});

async function handleEncryptedDownload(request) {
  try {
    const url = new URL(request.url);
    const fileId = url.searchParams.get('file');
    const expiry = url.searchParams.get('expiry');
    const mac = url.searchParams.get('mac');

    if (!fileId || !expiry || !mac) {
      return new Response('Invalid parameters', { status: 400 });
    }

    // Verify expiry
    if (Date.now() > parseInt(expiry)) {
      return new Response('Link expired', { status: 410 });
    }

    // Verify HMAC
    const data = `file=${fileId}&expiry=${expiry}`;
    const expectedMac = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(data + authConfig.crypto_base_key)
    );
    const expectedMacHex = Array.from(new Uint8Array(expectedMac))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    if (mac !== expectedMacHex) {
      return new Response('Invalid signature', { status: 403 });
    }

    // Get file from Google Drive
    const downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${authConfig.api_key}`;
    const response = await fetch(downloadUrl);

    if (!response.ok) {
      throw new Error('Failed to fetch file');
    }

    // Forward the response with download headers
    const headers = new Headers(response.headers);
    headers.set('Content-Disposition', 'attachment');

    return new Response(response.body, { headers });
  } catch (error) {
    console.error('Download error:', error);
    return new Response('Download failed', { status: 500 });
  }
} 
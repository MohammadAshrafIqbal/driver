const environment = 'production';
const serviceaccounts = [];
const randomserviceaccount = serviceaccounts[Math.floor(Math.random() * serviceaccounts.length)]; 
const domains_for_dl = [''];
const domain_for_dl = domains_for_dl[Math.floor(Math.random() * domains_for_dl.length)];
const blocked_region = [''];
const blocked_asn = []; 
const authConfig = {
  "siteName": "TheMoviesboss",
  "client_id": "296161728541-euvu4bnl1qht77qmc7re0f1vqqt29iq5.apps.googleusercontent.com",
  "client_secret": "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",
  "refresh_token": "1//04ntreTb1iBvrCgYIARAAGAQSNwF-L9Ir1J2S2Df9r6_sRRtrWkv4itXuFWjCU8jEv-FRSBZ9xgZh1qrCssPA3gIP5pwu5iokoeU",
  // ... rest of your auth config
};

// ... rest of your worker code 